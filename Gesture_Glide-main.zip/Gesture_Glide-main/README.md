# Gesture_Glide
Gesture-controlled virtual mouse  system using Python
